from itertools import combinations

def list_to_int(lst):
    return int(''.join(map(str, lst))) # list -> integer

def dfs(lst, k, visited, depth=0):
    key = (tuple(lst), k)
    if key in visited:
        return visited[key]
    
    if k == 0:
        lst_to_compare = lst[:]
        return lst_to_compare
    
    max_result = lst[:]
    for i, j in combinations(range(len(lst)), 2): # swap
        new_lst = lst[:]
        new_lst[i], new_lst[j] = new_lst[j], new_lst[i]
        candidate = dfs(new_lst, k - 1, visited, depth + 1)
        if list_to_int(candidate) > list_to_int(max_result):
            max_result = candidate

    visited[key] = max_result
    return max_result

def max_number_with_k_swaps(lst, k):
    visited = {}
    return dfs(lst, k, visited)


T = int(input())
for test_case in range(1,T+1):
    nums_lst = list(input().split())
    nums, num_change = nums_lst[0], nums_lst[1]
    nums_int = []

    num_change = int(num_change)
    for j in range(len(nums)):
        nums_int.append(int(nums[j]))
    
    result = max_number_with_k_swaps(nums_int, num_change)
    ans = int(''.join(map(str,result)))

    print(f'#{test_case} {ans}')



####
def dfs(cnt):
    global answer
     
    if cnt == count:
        temp = int(''.join(num))
        answer = max(answer, temp)
        return
     
    for i in range(len(num)):
        for j in range(i+1,len(num)):
            num[i], num[j] = num[j], num[i]
            temp = int(''.join(num))
             
            if (temp, cnt) not in visited:
                visited[(temp, cnt)] = 0
                dfs(cnt+1)
                # 끝까지 돌았다면 다시 원상복구 
            num[i], num[j] = num[j], num[i]
                 
 
T = int(input())
 
for tc in range(1, T+1):
    num, count = map(int, input().split())
    num = list(str(num))
    answer = 0
     
    visited = {}
    dfs(0)
    print("#{} {}".format(tc, answer))