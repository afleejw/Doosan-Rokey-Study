import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image
import cv2
from cv_bridge import CvBridge
import argparse

import requests
import numpy as np
import time

# ROS2 노드
class ColabYolo(Node):
    def __init__(self, webcam_ip, colab_ip):
        super().__init__('colab_yolo_node')
        qosprofile = QoSProfile(depth=1, reliability=ReliabilityPolicy.BEST_EFFORT)
        self.publisher_ = self.create_publisher(Image, 'yolo_image', qos_profile=qosprofile)
        self.timer = self.create_timer(0.1, self.timer_callback)
        self.bridge = CvBridge()
    
        # 영상 스트림 열기 (ip_webcam 주소)
        self.cap = cv2.VideoCapture(f'http://{webcam_ip}/video')
        if not self.cap.isOpened():
            self.get_logger().error('Failed to open video capture')
            rclpy.shutdown()

        # Colab 서버 IP 주소
        self.colab_ip = colab_ip
        # Colab 서버 로그인
        username = input("Enter your username: ")
        password = input("Enter your password: ")
        credentials = {"username": username, "password": password}
        res = requests.post(f'http://{colab_ip}/login', json=credentials)
        # 로그인 실패
        if res.status_code != 200:
            self.get_logger().error(f'Login failed: {res.text}')
            return
        # 토큰 저장
        self.get_logger().info('Login successful!')
        token = res.json()['token']
        self.headers = {'Authorization': f'Bearer {token}'}
        self.session = requests.Session()
        self.session.headers.update(self.headers)

    def timer_callback(self):
        start_time = time.time()

        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warn("Failed to receive video frame!")
            return
        
        frame = cv2.resize(frame, (640, 480), interpolation=cv2.INTER_NEAREST)
        encode_param = [int(cv2.IMWRITE_JPEG_QUALITY), 50]
        _, img_encoded = cv2.imencode('.jpg', frame, encode_param)
        self.get_logger().info(f'ip_webcam img read time: {time.time() - start_time}s')
        
        # YOLO 서버에 이미지 전송 후 결과 받기
        try:
            # response = requests.post(f'https://{self.colab_ip}/yolo', 
            #                             files={'image': img_encoded.tobytes()}, 
            #                             headers=self.headers,
            #                             timeout=5.0)
            response = self.session.post(
                f'https://{self.colab_ip}/yolo',
                files={'image': img_encoded.tobytes()},
                timeout=2.0
            )
            response.raise_for_status()  # HTTP 오류 발생 시 예외 처리
            result = response.json()
        except requests.exceptions.Timeout:
            self.get_logger().error(f'YOLO request timeout!')
        except Exception as e:
            self.get_logger().error(f'YOLO request failed: {e}')
            return
        
        self.get_logger().info(f'colab response time: {time.time() - start_time}s')

        # YOLO 결과 그리기
        for det in result.get("detections", []):
            x1, y1, x2, y2 = det["bbox"]
            cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
            label = f'{det["class"]}: {det["confidence"]:.2f}'
            cv2.putText(frame, label, (x1, y1 + 10), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0,255,0), 2)
        
        self.get_logger().info(f'add bounding box time: {time.time() - start_time}s')

        # ROS2 퍼블리시
        msg = self.bridge.cv2_to_imgmsg(frame, encoding="bgr8")
        self.publisher_.publish(msg)
        
        self.get_logger().info(f'img publish time: {time.time() - start_time}s')

import argparse

def main(args=None):
    parser = argparse.ArgumentParser(description='ROS2 Colab YOLO Node')
    parser.add_argument('--webcam_ip', type=str, required=True, help='IP address and port of the IP webcam (e.g., 192.168.0.180:8080)')
    parser.add_argument('--colab_ip', type=str, required=True, help='IP address and port of the IP Colab (e.g., 192.168.0.180:8080)')
    cli_args = parser.parse_args()

    rclpy.init(args=args)
    node = ColabYolo(cli_args.webcam_ip, cli_args.colab_ip)
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.cap.release()
        cv2.destroyAllWindows()
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()