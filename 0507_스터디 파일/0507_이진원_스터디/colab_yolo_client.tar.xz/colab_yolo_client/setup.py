from setuptools import find_packages, setup

package_name = 'colab_yolo_client'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='leejinwon',
    maintainer_email='afleedjw@gmail.com',
    description='ROS 2 node that communicates with a Flask YOLO server and publishes annotated image topics',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'flask = colab_yolo_client.flask_colab_client:main'
        ],
    },
)
